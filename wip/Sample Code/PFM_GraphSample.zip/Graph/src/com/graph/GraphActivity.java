package com.graph;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;

public class GraphActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_graph, menu);
        return true;
    }
    
    public void lineGraphHandler(View view)
    {
    	LineGraph line = new LineGraph();
    	Intent lineIntent = line.getIntent(this);
    	startActivity(lineIntent);
    }
    
    public void pieGraphHandler(View view)
    {
    	PieGraph pie = new PieGraph();
    	Intent pieIntent = pie.getIntent(this);
    	startActivity(pieIntent);
    }
}
