package com.graph;

import org.achartengine.ChartFactory;
import org.achartengine.model.TimeSeries;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import android.content.Context;
import android.content.Intent;

public class LineGraph {
	public Intent getIntent(Context context)
	{
		int [] x = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
		int [] y = {32, 12, 53, 74, 235, 126, 217, 81, 49, 110};
		TimeSeries series = new TimeSeries("Line1");
		for (int i = 0; i < x.length; i++)
		{
			series.add(x[i], y[i]);
		}
		XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();
		dataset.addSeries(series);
		
		XYMultipleSeriesRenderer mRenderer = new XYMultipleSeriesRenderer(); 
		XYSeriesRenderer renderer = new XYSeriesRenderer(); 
		mRenderer.addSeriesRenderer(renderer);
		
		Intent intent = ChartFactory.getLineChartIntent(context, dataset, mRenderer, "Line Graph");
		return intent;
	}
}
